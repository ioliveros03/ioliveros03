# MP3-UF3-Projecte
*Ivan Oliveros - 1r ASIX-DAM - Curs 21/22*

**POJO =** Pingui (String nom, String origen, int edat, double altura, double pes, boolean sexe)