package com.iesebre.model;
import java.io.Serializable;

/**
 * @author Ivan Oliveros
 */
public class Pingui implements Serializable {

    // VARIABLES D'ENTORN
    private String nom;
    private String origen;
    private int edat;
    private double altura;
    private double pes;
    private boolean sexe;

    // CREACIÓ CONSTRUCTOR
    /**
     * @param nom;
     * @param origen;
     * @param edat;
     * @param altura;
     * @param pes;
     * @param sexe;
     */
    public Pingui (String nom, String origen, int edat, double altura, double pes, boolean sexe) {
        this.nom = nom;
        this.origen = origen;
        this.edat = edat;
        this.altura = altura;
        this.pes = pes;
        this.sexe = sexe;
    }

    public String getNom() {
        return nom;
    }
    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getOrigen() {
        return origen;
    }
    public void setOrigen(String origen) {
        this.origen = origen;
    }

    public int getEdat() {
        return edat;
    }
    public void setEdat(int edat) {
        this.edat = edat;
    }

    public double getAltura() {
        return altura;
    }
    public void setAltura(double altura) {
        this.altura = altura;
    }

    public double getPes() {
        return pes;
    }
    public void setPes(double pes) {
        this.pes = pes;
    }

    public boolean isSexe() {
        return sexe;
    }
    public void setSexe(boolean sexe) {
        this.sexe = sexe;
    }


}
