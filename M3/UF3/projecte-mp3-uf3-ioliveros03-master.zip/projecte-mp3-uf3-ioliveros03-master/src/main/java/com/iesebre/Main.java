package com.iesebre;

import com.iesebre.model.Pingui;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void guardarLista(File file, List<Pingui> lista) {
        try {
            FileOutputStream ficheroSalida = new FileOutputStream(file);
            ObjectOutputStream objetoSalida = new ObjectOutputStream(ficheroSalida);
            objetoSalida.writeObject(lista);
            objetoSalida.close();
        } catch (FileNotFoundException e) {
            System.out.println("El fitxer no existeix");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

    }

    public static List<Pingui> obtenerLista(File file) {
        List<Pingui> lista = new ArrayList<>();

        try {
            FileInputStream fileInputStream = new FileInputStream(file);
            ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
            lista = (List<Pingui>) objectInputStream.readObject();
            objectInputStream.close();
        } catch (FileNotFoundException e) {
            System.out.println("Fitxer no existent");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return lista;
    }


    public static void main(String[] args) {

        File file = new File("C:\\MP3-UF3-Projecte\\src\\Pingui.txt");
        int opcion = 0;
        List<Pingui> lista = obtenerLista(file);
        Scanner sc = new Scanner(System.in);
        do {
            System.out.println("");
            System.out.println("");
            System.out.println("");
            System.out.println("");
            System.out.println("");
            System.out.println("");
            System.out.println("");
            System.out.println("");
            opcion = sc.nextInt();

            switch (opcion) {
                case 1:
                    System.out.println("");
                    System.out.println("");
                    System.out.println("");
                    sc.nextLine();
                    System.out.println("Nom");
                    String nom = sc.nextLine();
                    System.out.println("Origen");
                    String origen = sc.nextLine();
                    System.out.println("Edat");
                    int edat = sc.nextInt();
                    System.out.println("Altura");
                    double altura = sc.nextDouble();
                    System.out.println("Pes");
                    double pes = sc.nextDouble();
                    System.out.println("Sexe");
                    boolean sexe = sc.nextBoolean();

                    lista.add(new Pingui(nom, origen, edat, altura, pes, sexe));
                    guardarLista(file, lista);
                    break;

                case 2:
                    int index = 1;
                    System.out.println("");

                    if (lista.isEmpty()) {
                        System.out.println("No hi ha cap pingui");
                    } else {
                        for (int i = 0; i < lista.size(); i++) {
                            System.out.println("(" + index + ")");
                            System.out.println(list);
                            System.out.println("");
                            System.out.println("");
                            System.out.println("");
                            System.out.println("");
                            System.out.println("");
                        }

                    }
                    break;

                case 3:
                    System.out.println("");
                    System.out.println("");
                    System.out.println("");
                    String buscado = sc.next();
                    String mensaje = "No s'ha trobat\n";
                    Pingui x = null;

                    for (Pingui o : lista) {
                        if (o.getNom().equals(buscado)) {
                            mensaje = "Trobat\n";
                            x = o;
                        }
                    }
                    System.out.println("\n" + mensaje);
                    String[] headers = {"Nom", "Origen", "Edat", "Altura", "Pes", "Sexe"};
                    if (x != null) {
                        String[][] data = {{x.getNom(), x.getOrigen(), String.valueOf(x.getEdat()), String.valueOf(x.getAltura(), String.valueOf(x.getPes()), String.valueOf(sexe)}};
                        System.out.println(FlipTable.of(headers, data));
                    }
                    break;

                case 4:
                    System.out.println("");
                    System.out.println("");
                    System.out.println("");
                    String eliminar = sc.next();
                    String mensaje2 = "No s'ha trobat";
                    for (int i = 0; i < lista.size(); i++) {
                        if (lista.get(i).getNom().equals(eliminar)) {
                            lista.remove(i);
                            mensaje2 = "Pingui eliminat\n";
                        }
                    }
                    guardarLista(file, lista);
                    System.out.println(mensaje2);
                    break;

                case 5:
                    System.out.println("Modificar Pingui");
                    System.out.println("----------");
                    System.out.println("Indica el nom del Pingui");
                    String modificar = sc.next();
                    String mensaje3 = "No s'ha trobat";
                    Pingui pingui = null;
                    for (Pingui o : lista) {
                        if (o.getNom().equals(modificar)) {
                            pingui = 0;
                            mensaje3 = "Trobat";
                        }
                    }
                    System.out.println(mensaje3);
                    int opcion2 = 0;
                    if (pingui != null) {
                        do {
                            System.out.println("1. Modifica el nom");
                            System.out.println("2. Modifica l'origen");
                            System.out.println("3. Modifica l'edat");
                            System.out.println("4. Modifica l'altura");
                            System.out.println("5. Modifica el pes");
                            System.out.println("6. Modifica el sexe");
                            opcion2 = sc.nextInt();
                            switch (opcion2) {
                                case 1:
                                    sc.nextLine();
                                    System.out.println("Nom actual: " + pingui.getNom());
                                    pingui.setNom(sc.nextLine());
                                    break;
                                case 2:
                                    System.out.println("Origen actual: " + pingui.getOrigen());
                                    pingui.setOrigen(sc.nextLine());
                                    break;
                                case 3:
                                    System.out.println("Edat actual: " + pingui.getEdat());
                                    pingui.setEdat(sc.nextInt());
                                    break;
                                case 4:
                                    System.out.println("Altura actual: " + pingui.getAltura());
                                    pingui.setAltura(sc.nextDouble());
                                    break;
                                case 5:
                                    System.out.println("Pes actual: " + pingui.getPes());
                                    pingui.setPes(sc.nextDouble());
                                    break;
                                case 6:
                                    System.out.println("Sexe actual") + pingui.getSexe());
                                    pingui.setSexe(sc.nextBoolean());
                            }
                        }

                    }


            }
        }




        /*
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new VistaPrincipal();
            }
        });
        */
    }
}
